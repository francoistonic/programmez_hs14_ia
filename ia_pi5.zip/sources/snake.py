import pygame as pg
from random import randint

# Initialize Pygame
pg.init()

# Set up the game display
size = (400, 400)
screen = pg.display.set_mode(size)

# Create the snake and food objects
snake = [(200, 200), (180, 200), (160, 200)]
food = [(randint(0, 399 - 200), randint(0, 399 - 200))]

# Game variables
direction = "right"
speed = 5
apple_lives = 3
score = 0

# Game loop
running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

    # Update game state based on key presses
    keys = pg.key.get_pressed()
    if keys[pg.K_LEFT] and direction != "right":
        direction = "left"
    elif keys[pg.K_RIGHT] and direction != "left":
        direction = "right"

    # Move the snake
    for i in range(len(snake)):
        x, y = snake[i]
        new_x, new_y = x + (1 if direction == 'right' else -1), \
                      y + (1 if direction == 'down' else -1)

        # If the snake reaches its tail, remove it
        if (new_x < 0 or new_y < 0 or
                new_x >= 400 or new_y >= 400):
            score = 0
            break

        elif (new_x, new_y) in snake[len(snake)-1:]:
            score += 1
            apple_lives -= 1

        # If the snake eats food and doesn't die, add a tail and an apple 
        elif (new_x == food[0][0] and new_y == food[0][1]) \
                and not score > 0:
            snake.append((new_x, new_y))
            food = [(randint(0, 399 - 200), randint(0, 399 - 200))]
            score += 1

        # If the snake hits a wall, end game
        elif new_x == 0 or new_x == 400-1 or \
                 new_y == 0 or new_y == 400-1:
            running = False

    # Update the display
    screen.fill((0, 0, 0))
    for i in range(len(snake)):
        pg.draw.rect(screen, (255, 255, 255), pg.Rect(snake[i][0], 
                                                    snake[i][1],
                                                    25, 25))

    if len(food) == 1:
        # Create and display the apple
        apple = [(randint(0, 399 - 200), randint(0, 399 - 200)),
                 (randint(0, 399 - 200), randint(0, 399 - 200))]
        while apple in snake:
            apple = [(randint(0, 399 - 200), randint(0, 399 - 200)),
                     (randint(0, 399 - 200), randint(0, 399 - 200))]
        snake.append(apple[0])
        snake.append(apple[1])

    # Update the score and apple lives
    score_text = f"Score: {score}"
    pg.display.update()
    for event in pg.event.get():
        if event.type == pg.MOUSEBUTTONDOWN:
            x, y = pg.mouse.get_pos()
            # If the mouse click is inside the game area, 
            # add a tail to the snake and an apple if not already there
            if x >= 200 and y >= 200 and x <= 400 - 200 and \
                    y <= 400 - 200:
                snake.append((x, y))
                apple = [(randint(0, 399 - 200), randint(0, 399 - 200)),
                         (randint(0, 399 - 200), randint(0, 399 - 200))]
                if apple not in snake[len(snake)-1:]:
                    score += 1
                    apple_lives = 3

    # Wait for a short time before the next frame
    pg.time.wait(50)