import pygame
from random import randint

# Set up the display and set initial values for variables
pygame.init()
display = (800, 600)  
snake_speed = 10
food_speed = 5
level = 1
food_spawned = False
snake_body = []

def draw(screen):
    # Draw background
    screen.fill((255, 255, 255))

    # Draw food
    if not food_spawned:
        food_location = (randint(0, 800), randint(0, 600))
        snake_body.append(food_location)
        pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(food_location[0], food_location[1], 20, 20))
        food_spawned = True

    # Draw body
    for i in range(len(snake_body)):
        if i == 0:  # Draw tail
            pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(snake_body[i][0], snake_body[i][1], 20, 20))
        else:  # Draw body from head to tail
            pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(snake_body[i-1][0], snake_body[i-1][1], 20, 20))

    # Update the display
    pygame.display.update()

def move():
    global food_spawned, level
    for event in pygame.event.get():  # Check for any events like key press or mouse click
        if event.type == pygame.KEYDOWN:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]: 
                snake_body.insert(0, (snake_body[0][0] - snake_speed, snake_body[0][1]))
            elif keys[pygame.K_RIGHT]:
                snake_body.insert(0, (snake_body[0][0] + snake_speed, snake_body[0][1]))
            elif keys[pygame.K_UP]:
                snake_body.insert(0, (snake_body[0][0], snake_body[0][1] - snake_speed))
            elif keys[pygame.K_DOWN]:
                snake_body.insert(0, (snake_body[0][0], snake_body[0][1] + snake_speed))

    # If the tail hits the left or right edge of the screen, reset it to the top-left corner
    if snake_body[0][0] <= 0:
        snake_body.insert(0, (800 - 20, 600 - 20))
    elif snake_body[0][0] >= 800:
        snake_body.insert(0, (20, 600 - 20))

    # If the tail hits the top or bottom edge of the screen, reset it to the top-left corner
    if snake_body[0][1] <= 0:
        snake_body.insert(0, (800 - 20, 600 - 20))
    elif snake_body[0][1] >= 600:
        snake_body.insert(0, (20, 600 - 20))

    # If the tail hits itself, reset it to the top-left corner and decrease level by 1
    for i in range(len(snake_body) - 2):
        if snake_body[i] == snake_body[i+1]:
            level -= 1
            snake_body.insert(0, (800 - 20, 600 - 20))

    # If the tail hits food, decrement food count and increase score by 1000
    for i in range(len(snake_body)):
        if snake_body[i] == food_location:
            food_spawned = False
            level += 1
            score = 1000 + level * 100

            # Remove tail and add new body from the tail position to the head
            for j in range(len(snake_body)-1, i, -1):
                del snake_body[j]
            snake_body.insert(0, food_location)
            break

    # If level exceeds 10, game over
    if level > 10:
        gameOver = True
        pygame.quit()
        quit()

    # Move the head of the snake
    head = (snake_body[0][0], snake_body[0][1])
    for i in range(len(snake_body)):
        if i == len(snake_body) - 1:
            break
        snake_body[i] = (snake_body[i][0], snake_body[i][1])

    # If the head hits the left or right edge of the screen, reset it to the top-left corner
    if head[0] <= 0:
        head = (800 - 20, 600 - 20)
    elif head[0] >= 800:
        head = (20, 600 - 20)

    # If the head hits the top or bottom edge of the screen, reset it to the top-left corner
    if head[1] <= 0:
        head = (800 - 20, 600 - 20)
    elif head[1] >= 600:
        head = (20, 600 - 20)

    # If the head hits itself, reset it to the top-left corner and decrease level by 1
    for i in range(len(snake_body) - 2):
        if snake_body[i] == head:
            gameOver = True
            pygame.quit()
            quit()
            level -= 1

    # If the tail hits food, decrement food count and increase score by 1000
    for i in range(len(snake_body)):
        if snake_body[i] == food_location:
            food_spawned = False
            level += 1
            score = 1000 + level * 100

            # Remove tail and add new body from the tail position to the head
            for j in range(len(snake_body)-1, i, -1):
                del snake_body[j]
            snake_body.insert(0, food_location)
            break

def gameOver():
    # Print game over message and resets variables
    gameOverMsg = "Game Over! Level: " + str(level)
    print(gameOverMsg)
    score = score - 1000 * level
    pygame.quit()
    quit()
    return score

# Game loop
running = True
while running:
    for event in pygame.event.get():  # Check for any events like key press or mouse click
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    screen.fill((255, 255, 255))  # Fill the screen with white color

    draw(screen)  # Draw everything on the display

    move()  # Move the snake
    score = gameOver()  # Check for game over and update score

    if gameOver():
        running = False

    pygame.display.update()  # Update the display

pygame.quit()