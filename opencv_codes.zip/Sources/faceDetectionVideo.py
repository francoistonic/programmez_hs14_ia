import cv2

def displayFaces(frame, height, face_classifier):
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_classifier.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(80,80))
    
    countOfFaces = len(faces)

    text = f"Compte: {countOfFaces}"
    cv2.putText(frame, text, (10, int(height-20)), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 0), 1, cv2.LINE_AA)

    if countOfFaces != 0:
        for (x,y,w,h) in faces:
            cv2.rectangle(frame, (x,y), (x+w, y+h), (0, 255, 0), 2)

    cv2.imshow("video", frame)


cap = cv2.VideoCapture(0)

height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

face_classifier = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

while cap.isOpened():
    success, frame = cap.read() # Retourne un tuple avec deux arguments [bool, MatLike]

    if success: # Si l'image est lue avec succès
        frame = cv2.flip(frame, 1) # Inverser l'image horizontalement
        displayFaces(frame, height, face_classifier)

    # Interruption de la boucle en appuyant sur la touche "échap"
    if cv2.waitKey(1) & 0xFF == 27:
        break

# Libération des ressources permettant la capture de la vidéo
cap.release()

cv2.destroyAllWindows()