import cv2

# Fonction pour detecter les visages de chats sur une image passée en paramètre
def detect_cat_faces(image_path):

     # Charger l'image à partir du chemin spécifié
    image = cv2.imread(image_path)
    # Convertir l'image en niveaux de gris (pour améliorer la détection des visages)
    grey_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Charger le classificateur de visages de chats pré-entraîné
    cat_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalcatface_extended.xml')

    # Détecter les visages de chats dans l'image
    cat_faces = cat_cascade.detectMultiScale(grey_image, scaleFactor=1.1, minNeighbors=2)

    # Compter le nombre de visages detectés
    n_cat_faces = len(cat_faces)
    print(f"Nombre de têtes de chats détectées : {n_cat_faces}")

    # Tracer les rectangles sur les visages detectés
    for (x, y, w, h) in cat_faces:
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

     # Afficher l'image avec les rectangles autour des têtes de chats détectées
    cv2.imshow('Image avec têtes de chats détectées', image)
    cv2.waitKey(0)


image_path = './chat6.jpg'
detect_cat_faces(image_path)